import Head from 'next/head';

export default function Home() {
  return (
    <>
      <Head>
        <title>Future Academy</title>
        <meta name="description" content="Future Academy platform" />
        <link rel="icon" href="/favicon.ico" />
      </Head>
      <main className="flex min-h-screen flex-col items-center justify-center py-2 bg-gray-50">
        <h1 className="text-4xl font-bold mb-4">Welcome to Future Academy</h1>
        <p className="text-lg text-gray-700 max-w-xl text-center">
          This is the first step towards building a powerful, scalable and AI‑ready
          educational platform. Start by exploring the codebase and expanding
          features from here.
        </p>
      </main>
    </>
  );
}