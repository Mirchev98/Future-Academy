# Future Academy Frontend

This directory contains the frontend of the Future Academy project.
It uses **Next.js** with **TypeScript** and **TailwindCSS** to build a
modern, responsive web application.

## Getting Started

1. **Install Node.js** (version 18 or later) and Yarn or NPM.

2. **Install dependencies**:

   ```bash
   cd frontend
   npm install
   # or
   yarn install
   ```

3. **Run the development server**:

   ```bash
   npm run dev
   # or
   yarn dev
   ```

   Open [`http://localhost:3000`](http://localhost:3000) in your browser to see the
   result. The page will automatically reload when you edit files.

## TailwindCSS

TailwindCSS is already configured. Edit `tailwind.config.js` to customize
your design system. Global styles are defined in `styles/globals.css`.

## Next Steps

- Create components and pages for login, dashboard, lessons, and quizzes.
- Connect to the backend API (e.g. via `axios`) by setting up an
  environment variable such as `NEXT_PUBLIC_API_URL` pointing to
  your FastAPI server.
- Integrate AI features by calling backend endpoints and displaying
  results.