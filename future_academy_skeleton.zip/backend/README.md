# Future Academy Backend

This directory contains the backend portion of the Future Academy
project. It uses **FastAPI** to provide a RESTful API for the
frontend and exposes endpoints for health checks, user management,
lesson CRUD operations, and AI‑powered features.

## Getting Started

1. **Create a virtual environment** (recommended):

   ```bash
   python3 -m venv .venv
   source .venv/bin/activate
   ```

2. **Install dependencies**:

   ```bash
   pip install -r requirements.txt
   ```

3. **Run the development server**:

   ```bash
   uvicorn app.main:app --reload
   ```

   The API will be available at `http://localhost:8000`. Interactive
   API documentation is available at `/docs` (Swagger UI) and `/redoc` (ReDoc).

## Docker

To run the backend inside a Docker container, ensure you have
Docker installed and run:

```bash
docker build -t future-academy-backend .
docker run -p 8000:8000 future-academy-backend
```

This will expose the API on your host machine at port 8000.

## Next Steps

- Implement authentication and user registration (e.g. via JWT or
  Firebase Auth).
- Define data models for lessons, quizzes, and user profiles using
  Pydantic and persist them in a database (PostgreSQL recommended).
- Create endpoints for AI‑powered features (e.g., test generation,
  chat assistant) and integrate with the AI services defined in the
  project specification.