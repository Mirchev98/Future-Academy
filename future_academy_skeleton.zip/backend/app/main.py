"""
Future Academy Backend
----------------------

This is a minimal FastAPI application that will serve as the
foundation for the Future Academy backend. It defines a few basic
endpoints that can be expanded upon as the project grows. To run
locally, install the dependencies from ``requirements.txt`` and
start the server with Uvicorn:

.. code-block:: bash

   pip install -r requirements.txt
   uvicorn app.main:app --reload

The ``--reload`` flag enables hot-reloading during development.
"""

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel


class HealthCheckResponse(BaseModel):
    status: str


app = FastAPI(
    title="Future Academy API",
    description="Backend API for the Future Academy platform.",
    version="0.1.0",
    docs_url="/docs",
    redoc_url="/redoc",
)


@app.get("/", response_model=HealthCheckResponse)
async def root() -> HealthCheckResponse:
    """Root endpoint to verify the API is running."""
    return HealthCheckResponse(status="ok")


@app.get("/health", response_model=HealthCheckResponse)
async def health() -> HealthCheckResponse:
    """Health check endpoint used by uptime monitors and load balancers."""
    return HealthCheckResponse(status="healthy")


@app.get("/ping")
async def ping() -> dict[str, str]:
    """Simple ping endpoint for connectivity tests."""
    return {"message": "pong"}